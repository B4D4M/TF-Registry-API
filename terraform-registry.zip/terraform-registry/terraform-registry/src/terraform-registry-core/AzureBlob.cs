﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Identity;
using Azure.Storage.Blobs;

namespace terraform_registry.src.terraform_registry_core
{
    internal class AzureBlob
    {
        public string Host { get; set; }

        public DefaultAzureCredential Token { get; set; }
    }
}
